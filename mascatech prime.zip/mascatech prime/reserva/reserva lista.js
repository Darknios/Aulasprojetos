function login() {
    alert("Functionality to log in or register will be added here.");
}
