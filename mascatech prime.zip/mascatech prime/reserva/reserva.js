// script.js
document.getElementById('reservation-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the default form submission

    // Show the confirmation alert
    document.getElementById('confirmation-alert').style.display = 'block';
});

function closeAlert() {
    document.getElementById('confirmation-alert').style.display = 'none';
}
