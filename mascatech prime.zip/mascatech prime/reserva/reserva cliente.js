function login() {
    alert("Functionality to log in or register will be added here.");
}

function reservarMesa() {
    let ocupadas = document.getElementById('ocupadas');
    let livres = document.getElementById('livres');
    let fila = document.getElementById('fila');
    
    let ocupadasNum = parseInt(ocupadas.textContent);
    let livresNum = parseInt(livres.textContent);
    let filaNum = parseInt(fila.textContent);
    
    if (livresNum > 0) {
        ocupadas.textContent = ocupadasNum + 1;
        livres.textContent = livresNum - 1;
    } else {
        fila.textContent = filaNum + 1;
    }
}
